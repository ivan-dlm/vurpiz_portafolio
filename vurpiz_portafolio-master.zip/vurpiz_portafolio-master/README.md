# vurpiz_portafolio
Este es mi proyecto personal. La Creación de mi portafolio.
La intención es ir mostrando el progreso de mi portafolio y como se fue creando paso a paso.
